package corejava;
import java.util.Scanner;
class Q1
{
    public static void main(String args[])
    {
     Scanner k=new Scanner(System.in);
     System.out.println("Enter the number:");
     int num=k.nextInt();
     for(int i=1;i<=10;i++)
     {
      System.out.println(num+"x"+i+"="+(num*i));
     }
    }
}