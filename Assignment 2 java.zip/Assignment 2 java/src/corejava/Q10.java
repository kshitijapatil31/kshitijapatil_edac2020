package corejava;
import java.util.Scanner;
class Q10
{
  public static void main(String args[])
  {
      int sum=0;
      int i;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter element");
      int n=sc.nextInt();
      int arr[]=new int[n];
      for( i=0;i<n;i++)
      {
       arr[i]=sc.nextInt();
      }
       
       if(arr[i]%2==0)
       {
       sum+=arr[i];
       }
       System.out.println(sum);
       
       }
      }
  
