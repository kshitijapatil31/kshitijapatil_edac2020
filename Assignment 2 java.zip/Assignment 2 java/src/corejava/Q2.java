package corejava;
import java.util.Scanner;
class Q2
{
 public static void main(String args[])
 {
     int rev=0;
     Scanner k=new Scanner(System.in);
     System.out.println("Enter a number:");
     int num=k.nextInt();
     while(num !=0)
     {
      int rem=num%10;
      rev=rev*10+rem;
      num=num/10;
     }
     System.out.println(rev);
 }
}