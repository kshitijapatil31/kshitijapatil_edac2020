package corejava;
import java.util.Scanner;
class Q3
{
public static void main(String ars[])
{
Scanner n=new Scanner(System.in);
System.out.println("enter the number:");
int num=n.nextInt();
boolean prime=false;
for(int i=2;i<num;i++)
{
    if(num%i==0)
    {
     prime=true;
     break;
    }
}
if(prime)
{
    System.out.println(num+"is prime number");
    
}
else
{
 System.out.println(num+"is not prime number");
}
}
}