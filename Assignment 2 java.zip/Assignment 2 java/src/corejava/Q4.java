package corejava;
import java.util.Scanner;
class Q4
{
public static void main(String ars[])
{
    int sum=0;
Scanner n=new Scanner(System.in);
System.out.println("enter the number:");
int num=n.nextInt();
for(int i=12;i<=num;i=i+10)
  {
      System.out.println(i);
      sum+=i;
  }
   System.out.println(sum);
  
  }
}
