package corejava;
public class Q5
{
  public static void main(String args[])
  {
    int num ;
    int count;
    System.out.println("The prime numbers are:");
    for( num=23;num<=200;num++)
    {
        count=0;
    for(int i=2;i<= num/2;i++)
    { 
        if(num%i==0)
        {
         count++;
         break;
        }
    }
    if( count == 0 && num != 1)
    {
    System.out.println(num+" ");
    }
    } 
     
    
    
  }

}