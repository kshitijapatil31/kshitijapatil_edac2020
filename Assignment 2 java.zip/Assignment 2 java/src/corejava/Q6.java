package corejava;
import java.util.Scanner;
public class Q6
{
  public static void main(String args[])
  {
      byte sum=0;
      float avg;
      Scanner sc=new Scanner(System.in);
      int a1[]=new int[10];
      System.out.println("Enter the array:");
      for(int i=0;i<10;i++)
      {
       a1[i]=sc.nextInt();
       sum+=a1[i];
      }
      avg=(sum/10);
      System.out.println("sum of array ="+sum);
      System.out.println("average of array i="+avg);
  }
}  