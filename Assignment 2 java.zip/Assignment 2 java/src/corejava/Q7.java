package corejava;
import java.util.Scanner;
class Q7
{
    public static void main(String args[])
    {
      Scanner k=new Scanner(System.in);
      System.out.println("Enter size of the Array:");
      int n=k.nextInt();
      int arr[]=new int[n];
       System.out.println("Enter the Array element:");
      for(int i=0;i<=n;i++)
      {
       arr[i]=k.nextInt();
      }
      System.out.println("array before sorting");
       for(int x:arr)
       {
        System.out.print(x+" ");
       }//ascending order
      System.out.println("Araay element before sorting");
      for(int i=0;i<=n;i++)
      {
          for(int j=i+1;j<n;j++)
          {
           if(arr[i]>arr[j])
           { 
             int temp=0;
             temp=arr[i];
             arr[i]=arr[j];
             arr[j]=temp;
           
           }          
          }
       }
      System.out.println("\n Sorted array in ascending order");
      for(int i=0;i<n;i++)
      {
       System.out.println(arr[i]+" ");
      }

}
}
       
   

