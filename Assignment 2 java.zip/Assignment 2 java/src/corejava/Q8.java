package corejava;
import java.util.*;
class Q8{

public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter size of array");
int n=sc.nextInt();
int a[]=new int[n];
System.out.println("Enter elements of array");
        for(int i=0;i<a.length;i++)
         {

                a[i]=sc.nextInt();
          }
System.out.println("Array elements");
         for(int i:a)//array print
          {
             System.out.print(i+" ");
            }
System.out.println();
System.out.println("Array elements in reverse order");
for(int i=a.length-1;i>=0;i--)
{

System.out.print(a[i]+" ");

}
}
}