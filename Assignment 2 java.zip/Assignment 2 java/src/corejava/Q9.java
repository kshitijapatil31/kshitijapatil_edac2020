package corejava;
import java.util.*;
class Q9
{
  public static void main(String args[])
  {
      int i,search,num;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the array element");
      num=sc.nextInt();
      int a1[]=new int[num];
      System.out.println("array element");
      for( i=0;i<num;i++)
      {
      a1[i]=sc.nextInt();
      }
          System.out.println("Enter the array to find");
           search=sc.nextInt();
           for( i=0;i<num;i++)
      {
          if(a1[i]==search)
          {
               System.out.println(search + " is present at location " + (i + 1) + ".");  
          break;  
          }  
      }  
      if (i == num)  
      System.out.println(search + " isn't present in array."); 
          
    }
      
}
      
  
  


