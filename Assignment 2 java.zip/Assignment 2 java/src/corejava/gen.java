package corejava;
import java.util.Scanner;
class gen
{
   public static void main(String args[])
   { 
       //reverse array
       Scanner a1=new Scanner(System.in);
       System.out.println("size of array element:");
       int k=a1.nextInt();
       int arr[]=new int[k];
       System.out.println("Enter the Array element");
       for(int i=0;i<arr.length;i++)
       {
           arr[i]=a1.nextInt();
           
        }
       System.out.println("Display array");
       for(int x:arr)
       {
       System.out.println(x);
       }
        System.out.println();
         System.out.println("array in reverse order");
        for(int i=arr.length-1;i>=0;i--)
       {
         System.out.println(arr[i]);
  
        }
    }
}