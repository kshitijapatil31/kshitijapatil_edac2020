import java.util.Scanner;
import java.util.Scanner;
class Q13b
{
  public static void main (String args[])
 {
   Scanner s=new Scanner (System.in);
   System.out.println("Enter three numbers:");
   int a=s.nextInt();
   int b=s.nextInt();
   int c=s.nextInt();
   num = c>(a>b?a:b)? c
           System.out.println("num3 is greater than num1 and num2");
        }
 
}
}