package Oct2;
import java.util.*;
class Banking
{
int accountNo;
String accountName;
String accountType;
int balance;
 
   Banking()
   {
     balance=5000;
   
   }
   
   void setAccount(int no,String name,String type)
   {
       accountNo=no;
       accountName=name;
       accountType=type;
    }
   void showAccount()
   {
    System.out.println("Account Name="+accountNo+" "+"Account Name="+accountName+" "+"Account Type="+accountType);
   }
    void deposite(int depo)
    {
        int totalamt;
        totalamt=balance+depo;
        System.out.println("Account no :"+accountNo+"\nAccount Name :"+accountName+"\nType of account :"+accountType+"\nBalance :"+totalamt);
        
    }
    void withdrawal(int withdraw)
    {
        int totalamt=0;
        
        if(withdraw<=balance)
        {
            totalamt=balance-withdraw ;
        }
        else
        {
            System.out.println("Less Balance..Transaction Failed..");
        }
    System.out.println("Account no :"+accountNo+"\nAccount Name :"+accountName+"\nType of account :"+accountType+"\nBalance :"+totalamt);
    
    }
      
}
 public class Banking1
 {
     public static void main (String args[])
     {
       Scanner sc=new Scanner(System.in);
        System.out.println("Enter your account number :");
        int no=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter your name :");
        String name=sc.nextLine();
        System.out.println("Enter your type of account :");
        String type=sc.nextLine();
        Banking b1=new Banking();
        b1.setAccount(no,name,type);
        int ch;
     
     
     do
        {
        System.out.println("Enter your choice :");
        System.out.println("\n1.Withdraw\n2.Deposite\n3.Exit");
        ch=sc.nextInt();
        switch(ch)
        {
            case 1:
                System.out.println("How much amount you want to withdraw :");
                int withdraw=sc.nextInt();
                b1.withdrawal(withdraw);
                break;
                
            case 2:
                System.out.println("How much amount you want to deposite :");
                int depo=sc.nextInt();
                b1.deposite(depo);
                break;
                
        }
        }while(ch!=3);
    }
}
 
 
    

