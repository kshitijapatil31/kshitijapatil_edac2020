package Oct2;
class Employee
{
  private int empId;
  private String empName;
  private static int total;
 
  void set(int empId , String empName, int total)
  {
   this.empId=empId;
   this.empName=empName;
   this.total=total;
  }
  void display()
  {

     System.out.println("Id= "+empId+" "+"Name="+empName+" "+"total="+total);
  
  }
}
class EmployeeTest1
{
   public static void main(String args[])
   {
     Employee e=new Employee();
     e.set(551,"kshitija",10);
e.display();
     
      Employee e1=new Employee();
     e1.set(552,"onkar",20);
     e1.display();
             
      Employee e2=new Employee();
     e2.set(553,"Ranu",30);
     e2.display();
    }
}