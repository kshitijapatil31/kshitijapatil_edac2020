package Oct2;
class MathOp
{
static void sub(int k,int o)
{
    int l=k*o;
    System.out.println(l);
}
static void div (int k,int o)
{
    int y=k+o;
    System.out.println(y);
}

public static void main(String args[])
{
MathOp.sub(31,24);
MathOp.div(31,24);

}
}