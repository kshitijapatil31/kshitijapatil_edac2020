package Oct2;
class Employee1
{
  private int empId;
  private String empName;
 
  void set(int empId , String empName)
  {
   this.empId=empId;
   this.empName=empName;
  }
  void display()
  {

     System.out.println("Id= "+empId+" "+"Name="+empName);
  
  }
}
class EmployeeTest
{
   public static void main(String args[])
   {
     Employee e3=new Employee();
     e3.set(551,"kshitija",1);
     e3.display();
    }
}