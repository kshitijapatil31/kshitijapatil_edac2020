package Oct2;
import java.util.Scanner;
class PrimeNum2
{
public static void main(String args[])
{
int num1,num2;
int i=2;
System.out.println("Enter Any two Number:");
Scanner sc=new Scanner(System.in);
num1=sc.nextInt();
boolean m=false;
while (i<=num1/2)
{
if(num1%i==0){
m=true;
break;
}
}if(!m)
    System.out.println(num+" is a prime number");
else
    System.out.println(num+" is not a prime number");

++i;

}
}