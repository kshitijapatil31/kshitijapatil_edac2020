package Oct2;

 class Test5
{
    int i=10;
    
    void display()
    {
        System.out.println("Hi....");
    }
    
}
class TestDemo{
    public static void main(String args[])
    {
        Test5 t1 = new Test5();
        System.out.println(t1.i);
        t1.display();
        
    }
}