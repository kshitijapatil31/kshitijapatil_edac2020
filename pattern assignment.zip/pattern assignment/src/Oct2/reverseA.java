package oct2;
import java.util.Scanner;
class reverseA
{
  public static void main(String args[])
  {
   Scanner sc=new Scanner(System.in);  
   System.out.println("Array");
      int a1=sc.nextInt();
   int arr[]=new int[a1];
   for(int i=0;i<arr.length;i++)
   {
    System.out.print(arr[i]);
    }
   System.out.println();
   System.out.println("Reverse Array:");
  
  for(int i=arr.length-1;i>=0;i--)
  {
  System.out.print(arr[i]);
  
  }
      }
}