package Octstring3;
class Access
{
int a;
public int b;
private int c;
}
class Access2{
public static void main(String args[]){
Access o1=new Access();
   o1.a=10;
   o1.b=20;
  
  System.out.println(o1.a);
  System.out.println(o1.b);
 




}


}

