package Octstring3;
class Access4
{

private int c;

void setdata(int x)
{
  c=x;
}
  int getdata()
{
     return c;

}
}
class Access3
{
public static void main(String args[])
{
   Access4.op=new Access4();
   
   op.setdata(100);
  
   System.out.println(op.getdata);
 
}
}