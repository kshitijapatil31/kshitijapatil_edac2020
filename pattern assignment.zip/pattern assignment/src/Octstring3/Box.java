package octstring3;
class Box
{
      double depth;
      double height;
      double width;
      public static void main (String ars[])
      {
        Box b1=new Box();
        double vol;
        
        b1.depth=20;
        b1.height=30;
        b1.width=40;
        
        vol=b1.depth*b1.height*b1.width;
        System.out.println("volume="+vol);
      
      }
              


}
