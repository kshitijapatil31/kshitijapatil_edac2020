package octstring3;
class Box1
{
      double depth;
      double height;
      double width;
      
}
class Box2
{
      public static void main (String ars[])
      {
        Box1 b1=new Box1();
        Box1 b2=new Box1();
        double vol;
        
        b1.depth=20;
        b1.height=30;
        b1.width=40;
        
        vol=b1.depth*b1.height*b1.width;
        System.out.println("volume="+vol);
        
        b2.depth=10;
        b2.height=20;
        b2.width=30;
        
        vol=b2.depth*b2.height*b2.width;
        System.out.println("volume="+vol);
      }
              


}