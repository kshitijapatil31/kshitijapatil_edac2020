package octstring3;
class BoxTest
{
      double depth=10;
      double height=20;
      double width=30;
      
        void volume(double d,double h,double w)
        {
            double depth=d;
            double height=h;
          double width=w;
            
            
        double v=depth*height*width;
        System.out.println("volume="+v);
      
        }
}
class Box3
{
      public static void main (String ars[])
      {
        BoxTest b1=new BoxTest();
        BoxTest b2=new BoxTest();
        b1.volume(10,20,30);
        b2.volume(1,2,3);
        
       }
              


}