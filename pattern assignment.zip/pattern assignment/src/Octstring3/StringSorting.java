package Octstring3;
class StringSorting
{
   public static void main(String[]args)
   {
       int min = 0;
       String temp;
     String a[]={"onkar","ranu","anu","guddu","siddhi","kshitija","aarvi","sharvin","kunal","maya"};
     for(int i=0;i<a.length;i++)
     {
         for(int j=i+1;j<a.length;i++)
         {
          if (a[j].compareTo(a[min])<0)  
          {
              min=j;
              
          }
         }
     
        temp=a[i];
        a[i]=a[min];
        a[min]=temp;
        
     }
   for(int i=0;i<a.length;i++)
    {
     System.out.println(a[i]+" ");
     }

}


}

 