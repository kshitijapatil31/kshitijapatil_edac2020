package Octstring3;
class StringTest1
{
  public static void main(String args[])
  {
  String s1="Hello";
  String s2="Ratanagiri";
  String s3="Maharastra";
  String s4="MH08";
  System.out.println(s4);
  System.out.println(s4+" "+s3);
  System.out.println(s4+s2+s3);
  System.out.println(s4.charAt(1));
  
  
  
  }


}