package Octstring3;
class StringTest2
{
  public static void main(String args[])
  {
   String str[]={"kshitija","nihal","madhavi","pradip"};
   for (int i=0;i<str.length;i++)
   {
   System.out.println("str["+"]="+str[i]);
   
   }
  
  }


}