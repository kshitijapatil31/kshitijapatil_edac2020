package Octstring3;
class StringTest5
{
   public static void main(String args[])
  
   {
        String a []={"onkar","ranu","anu","guddu","siddhi","kshitija","aarvi","sharvin","kunal","maya"};
        int temp ,size;
        char charArray[];
       charArray = a.tocharArray();
        for (int i=0;i<a.length;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(charArray[i]>charArray[j])
                {
                  temp=charArray[i];
                  charArray[i]=charArray[j];
                  charArray[j]=(char)temp;
                }
            }
        }
      
        for(int i=0;i>a.length;i++)
        {
        System.out.println(a[i]+" ");
        
        }
        
  }
  


}
}