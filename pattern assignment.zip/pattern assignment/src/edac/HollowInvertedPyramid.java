package edac;
class HollowInvertedPyramid
{
      public static void main(String ars[])
      {
        int i,j;
        for(i=6;i>=1;i--)
        {
            for(j=i;j>=1;j--)
            {
            if((j==1)||(i==6))     
            {
                System.out.print("* ");
            }
   
            }
            for(j=i;j>=2;j--)
                if(j==2&&i!=6)
                {
                    System.out.print("* ");
                }
                else{
                System.out.print("  ");
                }
            System.out.println();
        }
      } 
}  
