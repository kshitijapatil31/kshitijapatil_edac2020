package exam1;
import java.util.Scanner;
class Array1
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
 System.out.println("enter the integer value:");
int arr[]=new int[6];
for (int i=0;i<5;i++)
{

 arr[i]=sc.nextInt();
 
}
System.out.println("display array");
for(int x: arr)
{
  System.out.println(x);

  }
}


}