package exam1;
class Array2
{
public static void main(String args[])
{
float arr[]=new float[3];
for(float x:arr)
{
System.out.println(arr);

}

}
}