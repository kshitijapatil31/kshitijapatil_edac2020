package exam1;
class Array4
{
public static void main(String args[])
{
char arr[]={'o','n','k','a','r'};
char arr1[]=new char[]{'h','i','!'};
for(char a:arr)
{
System.out.println(a);
}

}


}