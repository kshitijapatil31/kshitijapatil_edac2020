package exam1;
class Array5
{
public static void main(String args[])
{
char a1[]={'r','a','n','u'};
char a2[]={'o','n','k','a','r'};
char a3[]={'l','o','v','e'};
char a4[]={'l','o','v','e'};
char arr[][]=new char[4][];

arr[0]=a1;
arr[1]=a2;
arr[2]=a3;
arr[3]=a4;
for(char i=0;i<5;i++)
{
for(char j=0;j<4;j++)
{
System.out.print(arr[i][j]);
}
}


}
}