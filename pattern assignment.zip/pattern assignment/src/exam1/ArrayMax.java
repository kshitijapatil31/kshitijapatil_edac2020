package exam1;
class ArrayMax
{
    static int arr[]={10,20,30,450,312,2000};
    static int minimum()
  {
  int min=arr[0];
  for(int i=1;i<arr.length;i++)
  if (min>arr[i])
  min=arr[i];
  return min;

  }

  public static void main(String args[])
{
  System.out.println("Manimum number="+minimum());

}
}