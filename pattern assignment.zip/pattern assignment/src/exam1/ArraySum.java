package exam1;
class ArraySum
{ 
   static int arr[]={10,2,30};
  static int sum()
  {
   int sum=0;
   for(int i=0;i<arr.length;i++)
   sum+=arr[i];
   return sum;
  }
public static void main(String args[])
{
System.out.println("sum="+sum());
}
}


