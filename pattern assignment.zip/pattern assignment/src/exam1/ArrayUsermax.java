package exam1;
import java.util.Scanner;
class ArrayUsermax
{
public static void main(String args[])
{
   int n ,max;
Scanner sc=new Scanner(System.in);
System.out.print("enter the number of elements in array");
n=sc.nextInt();
int arr[]=new int[n];
System.out.println("enter the array element");
for(int i=0;i<n;i++)
{
    arr[i]=sc.nextInt();
}  
max=arr[0];
for(int i=0;i<n;i++)
{
 if(max<arr[i])
 {
    max=arr[i];

}
}
   System.out.println("maximum no ="+max);


}
}





        