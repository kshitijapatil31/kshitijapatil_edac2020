package exam1;
class Constructor
{
    double pr;
    String s1;
Constructor()
{
 
    pr=50000;

}
Constructor(double p,String name)
{
 pr=p;
 s1=name;
}
void display()
{
System.out.println(pr+s1);
}
public static void main(String args[])
{
Constructor c1=new Constructor(1000,"ranu");
Constructor c2=new Constructor();
c2.display();
c1.display();

}
        
        
        }