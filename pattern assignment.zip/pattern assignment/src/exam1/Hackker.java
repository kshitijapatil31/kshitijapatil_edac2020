package exam1;
import java.util.Scanner;
class Hackker
{
    public static void main(String args[])
    {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the number;");
    int n=sc.nextInt();
    if( n%2==1 || n>=6&&20>=n )
    {
    System.out.println("weird");
    }
    else
    if( n%2==0 || n>=2&&5>=n)
    {
     System.out.println("not weird");
    }
    
    }
    }
