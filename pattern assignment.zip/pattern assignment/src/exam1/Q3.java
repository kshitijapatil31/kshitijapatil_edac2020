package exam1;
import java.util.Scanner;
class Q3
{        
     public static void main(String args[])
     { 
         int num1,num2,num3;
         int avg;
          Scanner sc=new Scanner(System.in);
          
          System.out.println("ENter first  njumbers");
          num1=sc.nextInt();
          System.out.println("ENter first  njumbers");
          num2=sc.nextInt();
          System.out.println("enter the third number");
          num3=sc.nextInt();
          avg=(num1+num2+num3)/3;
          System.out.println(avg);
     }
}