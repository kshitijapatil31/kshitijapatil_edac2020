package exam1;
class pyramid
{
public static void main(String args[])
{
for(int i=1;i<=9;i++)
{
for(int j=9;j>=i;j--)
{
System.out.print(" ");
}
for(int m=1;m<=i;m++)
{
System.out.print(i+" ");
}
for(int k=10;k<=i;k++)
{
System.out.print(i+" ");
}

System.out.println();
}
}
}
