package newpackage;
abstract class Car
{ 
    int no;
    int price;
  
    Car()
    {
       System.out.println("Car constructor");  
    }
  void details()
  {
      System.out.println(no);
      System.out.println(price);
  }
  abstract void speed();
  
}
class Honda extends Car
{
    int model;
    Honda()
    {
        super();
        System.out.println("Honda constructor");
    }
    void speed()
    {
      System.out.println("70 kmph");
    }
    
}
class Maruti extends Car
{
    Maruti()
    {
       
         System.out.println("Maruti constructor");
    }
    void speed()
    {
        System.out.println("60kmph");
        
    }
    
}
class AbstractTest
{
  public static void main(String args[])
  {
    Car c=new Maruti();
    c.speed();
      Honda h=new Honda();
     h.speed();
  }
}