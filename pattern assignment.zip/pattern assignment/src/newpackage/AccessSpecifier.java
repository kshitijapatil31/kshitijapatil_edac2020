package newpackage;
class Animal
{
    public int a=10;
    private int b=20;
    protected int c=30;
    int d=40;
    Animal()
    {
        
    }
    
    void show()
    {
        System.out.println(a);
    }
            
    
}
class Dog extends Animal
{
    void show()
    {
        super.show();
        System.out.println(d);
    }
}
class Cat extends Animal
{
    
}
class AccessSpecifier
{
    public static void main(String args[])
    {
        Animal a1=new Animal();
        a1.show();
    }
}