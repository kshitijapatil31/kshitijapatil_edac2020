package newpackage;
class Test
{
    public int a;
    private int b;
    protected int c;
    int d;
    final int e=20;;
      
     
        Test()
    {
        a=10;
       
    }
       Test(int k)
    {
        super();
        a=10;
       
    } 
       Test(int k,int p)
    {
       
        a=10;
       
    } 
     void display()
    { 
       
        System.out.println(b);
        System.out.println(e);
    }
    
}
class Test2 extends Test
{
    void display()
            
    {
        super.display();
        
        System.out.println(a);
        System.out.println(d);
    }
}
class AccessTest
{
  public static void main(String args[])
  {
      Test2 obj=new Test2();
     System.out.println(obj.a);
      obj.display();
  }
}