package newpackage;
class Cricket
{
    String name;
    int jersyNo;
    String country;
    
    Cricket()
    {
        
    }
    Cricket(String x,int y,String z)
    {
        name=x;
        jersyNo=y;
        country=z;
        
    }
    void display_name()
    {
     System.out.println(name);
    }
    void display_details()
    {
       System.out.println("name"+name);
       System.out.println("jersy No"+jersyNo);
       System.out.println("Country"+country);
       
    }
}
class AllRounder extends Cricket
{
   int runs;
   int wickets;
   
    void dispaly_record(int r,int w)
    {
       System.out.println("Runs"+runs);
       System.out.println("wickets"+wickets);
    }
    void display_details()
    {
        super.display_details();
        System.out.println("Runs"+runs);
    }

    void display_record(int x, int y) 
    {
        
       //To change body of generated methods, choose Tools | Templates.
    }
}
class Kipper extends Cricket
{ 
    int wickets;
    void Allwickets()
    {
       System.out.println("Wickets"+wickets); 
    }
     void display_details()
    {
        super.display_details();
        System.out.println("Wickets"+wickets);
    }
    
    
}
class AccesibilityTest
{
    public static void main(String args[])
    {
        AllRounder r=new AllRounder();
        r.display_record(100,200);
        Cricket cric=new Kipper();
        cric.display_details();
        
    }
    
}