package newpackage;
import java.util.Scanner;
class Array
{
 public static void main(String args[])
 { 
    int a[]=new int[50];
     
        for(int i=1;i<50;i++)
     {
         System.out.println("Enter any value:");
        
     }
     for (int i=1;i<5;i++)
     {
     System.out.println(a[i]);
     }
    
 }
}