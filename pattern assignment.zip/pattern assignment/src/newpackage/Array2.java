package newpackage;
import java.util.Scanner;
class Array2
{
 public static void main(String args[])
 {
     Scanner sc =new Scanner(System.in);
     int a1[]=new int[5];
     for(int i=0;i>5;i++)
     {
     System.out.println("Enter any number");
     }
 }
}