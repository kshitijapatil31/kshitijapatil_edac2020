package newpackage;
import java.util.Scanner;
class Array3
{
 public static void main(String args[])
 {
     Scanner sc =new Scanner(System.in);
      int a1[] =new int[5];
     System.out.println("Enter any number:");
     for(int i=0;i<5;i++)
     {
     a1[i] =sc.nextInt();
     }
     System.out.println("Display the array:");
     for(int x:a1)
     {
     System.out.println(x);
     }
 }
}

 