package newpackage;
import java.util.Scanner;
class Array4
{
 public static void main(String args[])
 {
    char a1[] = {'a','b','c'};
    char a2[] = new char[]{'a','b','c'};
    for(char a:a2)
    {
    System.out.println(a);
    }
 }
}