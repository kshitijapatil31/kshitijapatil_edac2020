package newpackage;
import java.util.Scanner;
class Array5
{
 public static void main(String args[])
 {
    char a1[] = {'a','b','c'};
    char a2[] = {'a','b','c'};
    char a3[] = {'a','b','c'};
    char a4[] = {'a','b','c'};
    char arr[][]=new char[4][];
    
    arr[0]=a1;
    arr[1]=a2;
    arr[2]=a3;
    arr[3]=a4;
    for(int i=0;i<3;i++)
    {
    for(int j=0;j<3;j++)
    {
    System.out.print(arr[i][j]);
    }
    }
}
}