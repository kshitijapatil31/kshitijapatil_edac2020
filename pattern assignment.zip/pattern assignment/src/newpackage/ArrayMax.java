package newpackage;
import java.util.Scanner;
public class ArrayMax
{
    public static void main(String args[])
    {
      int max=0; 
      Scanner sc=new Scanner(System.in);
      int a1[]=new int [5];
      System.out.println("Enter any Number:");
      
      for (int i=0;i<5;i++)
      {
          if(a1[i]> max) 
          {
             max=a1[i];
      
          }
         System.out.println("Maximim value is:"+ max);
      }
      
    }
}