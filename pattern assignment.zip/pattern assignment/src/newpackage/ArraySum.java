package newpackage;
import java.util.Scanner;
public class ArraySum
{
      public static void main(String args[])
      {
      int max=0;
      Scanner sc=new Scanner(System.in);
      int a1[]=new int [8];
      System.out.println("Enter any element:");
      for (int i=0;i<8;i++)
      { 
          a1[i]=sc.nextInt();
          
      }
      max=a1[0];
      for(int i=0;i<8;i++) 
      { 
        for(int x:a1)
      {
       if (max < a1[i]);
       {
        max=a1[i];   
       }
      {
          System.out.println("maximumvalue is:"+max);
      }
      }      
              
              
              
              
      }             
}
}