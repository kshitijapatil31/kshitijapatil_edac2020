package newpackage;
class Emplyoee
{
    String name;
    Emplyoee(String nm)
    {
     name=nm;   
    }
  
   
}
class Bank
{
    String name;
   Bank(String nm)
   {
      name=nm; 
   }
}
class AssociationDemo
{
    public static void main(String args[])
    {
      Emplyoee emp=new Emplyoee("RANU");
      Bank bk=new Bank("BOI");
      System.out.println(emp.name+"has account"+bk.name);
    }
}