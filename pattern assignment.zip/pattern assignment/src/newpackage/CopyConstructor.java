package newpackage;
class Copy
{
   int a;
   int b;
   Copy(int a,int b)
   {
       this.a=a;
       this.b=b;
   }
   Copy(Copy c)
   {
       this.a=c.a;
       this.b=c.b;
   }
   public int display()
   {
       return(a+b);
   }

}
class CopyConstructor
{
    public static void main(String args[])
    {
        Copy cop=new Copy(5,10);
        Copy cop2=new Copy(cop);
        System.out.println(cop2);
    }
}
