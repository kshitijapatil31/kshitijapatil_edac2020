package newpackage;
class PersonalDetails
{
    String state;
    String emailId;
    void displayDetails()
    {
        
        System.out.println(state);
        System.out.println(emailId);
    }
    
}
class Cricketer
{
  PersonalDetails pd;
 String name;
 int totalMatches;
 Cricketer(String s,String e,String n,int t)
 {
     pd=new PersonalDetails();
     pd.state=s;
     pd.emailId=e;
     this.name=n;
     this.totalMatches=t;
     
 }
 void display()
 {
     System.out.println(name);
     System.out.println(totalMatches);
     System.out.println(pd.state);
     pd.displayDetails();
 }
 
}
class Employee
{
    PersonalDetails pd;
    String name;
    double salary;
Employee(String s,String e,String n,double t)
 {
     pd=new PersonalDetails();
     pd.state=s;
     pd.emailId=e;
     this.name=n;
     this.salary=t;
     
 }
 void display_details()
 {
     System.out.println(name);
     System.out.println(salary);
     System.out.println(pd.state);
     pd.displayDetails();
 }
    
}
class DEmo
{ 
     public static void main(String args[])
     {
         Cricketer cric=new Cricketer("india","abcd","sachin",2000);
         Employee emp=new Employee("india","xyz","neha",2000.55);
       cric.display();
        emp.display_details();
     }
    
}