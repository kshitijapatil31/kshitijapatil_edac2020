package newpackage;
class Box
{
    void fun()
    {
        
    }
}
class ExceptionDemo
{
    public static void main(String args[])
    {
        int x=5;
        int y=0;
        int i[]={10,20,30,40};
       //Box t=nul,l;
       //System.out.println(t);
        //t.fun();
        try
        {
        
        System.out.println(x/y);
         System.out.println(i[5]);
        }
        
        catch(ArithmeticException e)
        {
        System.out.println("Arithmetic exception handle");
        System.out.println(e);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
        System.out.println("ArratINdexout of boundsException is handle");
        System.out.println(e.getMessage());
        }
        System.out.println("program run successfully");
    }
}