package newpackage;
class Box1
{
    void fun()
    {
        
    }
}
class ExceptionHandling
{
    public static void main(String args[])
    {
        int x=5;
        int y=0;
        int i[]={10,20,30,40};
       //Box t=nul,l;
       //System.out.println(t);
        //t.fun();
        try
        {
        
        System.out.println(x/y);
         System.out.println(i[3]);
        }
        
        catch(Exception e)
        {
        System.out.println("Arithmetic exception handle");
        }
        /*catch(ArrayIndexOutOfBoundsException e)
        {
        System.out.println("ArratINdexout of boundsException is handle");
        }*/
        finally{
        System.out.println("program run successfully");
        }
    }
}