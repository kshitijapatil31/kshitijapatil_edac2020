package newpackage;
class Box2
{
    int a=10;
    int b=0;
    public void myFun()
    {
        System.out.println("myfun of Box2");
        //fun();
    }
    
    /*void fun()
    {
        System.out.println(a/b);
       //  System.out.println(i[5]);
    }*/
    public void ArrayIndex()
    {
      int i[]={10,20,30};
      System.out.println(i[5]);
      
    }
}
class ExceptionTest
{
    public static void main(String args[])
    {
        /*int x=5;
        int y=0;
        int i[]={10,20,30,40};
       //Box t=nul,l;
       //System.out.println(t);
        //t.fun();*/
        Box2 b=new Box2();
        try
        {
        
        System.out.println("Exception Throw here");
         b.ArrayIndex();
        }
        
        /*catch(Exception e)
        {
        System.out.println("Arithmetic exception handle");
        e.printStackTrace();
        }*/
       catch(ArrayIndexOutOfBoundsException e)
        {
        System.out.println("ArratINdexout of boundsException is handle");
        //e.printStackTrace();
        //System.out.println(e.getMessage()+"sum");
        System.out.println(e.toString());
        System.out.println("print the details");
        }
        finally
        {
            System.out.println("finally of exception");
        }
        System.out.println("program run successfully");
    }
}