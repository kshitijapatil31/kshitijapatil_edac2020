package newpackage;
interface MyInterface
{
    int a=10;
    int b=20;
    
    void show();
    
   
}
class MyTest implements MyInterface
{
     public void show()
     {
         System.out.println("");
     }
     void display()
     {
         System.out.println("Display Mytest");
     }
}
class InterfaceDemo
{
    public static void main(String args[])
    {
        MyInterface mi;
        mi=new MyTest();
        mi.show();
    }
}