package newpackage;
class TestT4
{
    int x;
    int y;
    
    TestT4()
    {
     System.out.println(x);   
    }
    
    TestT4(int x)
    {
      System.out.println(x);  
    }
    TestT4(int x,int y)
    { 
        this();
     System.out.println(x);
     System.out.println(y);
    }
    void show()
    {
    System.out.println(x);
    System.out.println(y);
    }
    void show(int x)
    {
        this.x=x;
       System.out.println(x);
       System.out.println(y);
    }
    void show(int x,int y)
    {
        this.x=x;
        this.y=y;
      System.out.print(x);
      System.out.print(y);
    }
}
class MethodLoading
{
    public static void main(String args[])
    {
        TestT4 t1=new TestT4();
        TestT4 t2=new TestT4(1,2);
        t1.show(10,20);
        t1.show(30);
        t1.show();
       
    }
}