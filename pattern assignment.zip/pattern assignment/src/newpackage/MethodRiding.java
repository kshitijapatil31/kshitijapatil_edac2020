package newpackage;
class Criketer
{ 
    String name;
    String country;
    int totalMatches;
    
    Criketer()
    {
    
    }
    Criketer(String nm,String c,int tm)
    {
      name=nm;
      country=c;
      totalMatches=tm;
      
    }
    void displayName()
    {
        System.out.println(name);
    }
    
    void displaydetails ()
    {
        this.name=name;
        this.country=country;
        this.totalMatches=totalMatches;
        
        System.out.println(name);
        System.out.println(country);
        System.out.println(totalMatches);
    }
     
}
class Batsman extends Criketer
{
    int total_Runs;
    Batsman(String nm, String c,int tm)
    {
        super(nm,c,tm);
        
    }
    
    void totalRuns(int total_Runs)
    {
        this.total_Runs=total_Runs;
        System.out.println(total_Runs);
    }
    void displaydetails (String name , String country, int totalmatches)
    {
        super.displaydetails();
        System.out.println(total_Runs);
    }
    
}
class Bowler extends Criketer
{
  int totalWickets;
  
  void totalWickets(int totalWickets)
  {
      this.totalWickets=totalWickets;
      System.out.println(totalWickets);
  }
}

class MethodRiding
{
    public static void main(String args[])
    {
      //Criketer ct=new Criketer();
      //ct.displaydetails();
      Batsman bt=new Batsman("virat","india",200);
      bt.displaydetails("ranu","india",100);
      bt.totalRuns(18000);
      bt.displayName();
    }
}