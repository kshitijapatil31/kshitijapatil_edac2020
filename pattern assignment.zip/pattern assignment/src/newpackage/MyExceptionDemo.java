package newpackage;
class MyException3 extends Exception
{ 
    String myMsg;
    
    MyException3(String myMsg)
    {
      super(myMsg);  
      this.myMsg=myMsg;
    }
    public String getMessage()
    {
        String str=super.getMessage();
        return"MyException:"+str;
    }
    public String toString()
    {
        return"customized";
    }
}
class MyExceptionDemo
{
    public static void main(String args[])
    {
        int a=16;
        try
        {
        if(a<18)
        {
            MyException3 ecp=new MyException3("Show my Message");
            throw ecp;
        }
        else
        {
            System.out.println("id generated");
        }
        }
        catch(MyException3 obj)
        {
           System.out.println("Exception handle carefully");
           System.out.println(obj);
        }
        //System.out.println();
    }
}