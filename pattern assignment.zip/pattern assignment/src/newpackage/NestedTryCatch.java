package newpackage;
class NestedTryCatch
{
    public static void main(String args[])
    {
        int a=5;
        int b=0;
        int i[]={10,20,30};
        
        try
        {
            System.out.println(a/b);
            try
            {
                System.out.println(i[5]);
            }
            catch(ArithmeticException exp)
            {
                System.out.println("ArithmeticException+1");
            }
        }
        catch(ArithmeticException e)
        {
          System.out.println("Arithmetic+2");  
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("ArratIndexBound");
        }
    }
}