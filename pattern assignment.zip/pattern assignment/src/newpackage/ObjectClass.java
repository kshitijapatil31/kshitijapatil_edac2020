package newpackage;

class Second
{
    void fun()
    {
        System.out.println("fun of Second");
    }
    static Second getobj()
    {
        Second on=new Second();
        return on;
    }
    protected void finalize()
    {
        System.out.println("finalize method of second");
    }
    
}
class ObjectClass
{
    public static void main(String args[])
    {
        Second s=new Second();
        s.fun();
        s=null;
        System.gc();
        Runtime.getRuntime().gc();
        Second.getobj().fun();
    }
}