package newpackage;
class Single
{
    public static void main(String args[])
    {
    int a=5;
    int b=0;
    int i[]={10,20,30};
    try
    {
        System.out.println(a/b);
         System.out.println(i[4]);
    }
    catch(ArithmeticException | ArrayIndexOutOfBoundsException exp)
    {
      System.out.println("Arithmetic Exception");
         System.out.println("Array exception");  
    }
    finally
    {
        System.out.println("finally block executed");
         
    }
    System.out.println("program run successfully");
     
    }       
}