package newpackage;

import static newpackage.TestT3.name;

class TestT3
{
    static String name ;
    int b;
    int c;
    
   
    {
       
       b=2;
       c=3;
       
    }
    static
    {
        name="ranu";
    }
    static void display()
    {
        System.out.println(name);
    }
}
class StaticTest
{
    public static void main(String []args)
    {
        TestT3 t1=new TestT3();
        System.out.println(TestT3.name);
        System.out.println(t1.b);
        TestT3.display();
    }
}