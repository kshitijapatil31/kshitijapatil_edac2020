package newpackage;
class TestT2
{ 
    int x;
    int y;
    int z=48;       
     TestT2()
    {  
        this(10,20);
        x=50;
        System.out.println(x);
    }
    TestT2(int x)
    {
        //this();
        this.x=x;
        System.out.println(x);
        
        
    }
    TestT2(int x,int y)
    {  
        this(10);
        this.x=x;
        this.y=y;
      System.out.println(x);
      System.out.println(y);  
    }
}
class ThisTest
{
    public static void main(String args[])
    { 
        TestT2 t=new  TestT2();
        TestT2 t1=new  TestT2(1,2);
        TestT2 t2=new  TestT2(3);
        System.out.println(t2.z);
        
    }
}