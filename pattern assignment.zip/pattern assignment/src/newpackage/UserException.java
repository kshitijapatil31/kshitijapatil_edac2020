package newpackage;
class ExceptionDemo2 extends Exception
{
     ExceptionDemo2()
     {
         
     }
   ExceptionDemo2(String msg)
   {
       super(msg);
   }
   public String getMessage()
   {
       String msg=super.getMessage();
       return"mycustomized exception:"+msg;
   }
}
   class UserException
   {
       public static void main(String args[])
       {
          int age=16;
          try
         {
             if(age <18)
             {
                 ExceptionDemo2 excp=new ExceptionDemo2("print my msg");
                 throw excp;
               }else
             {
                 System.out.println("voter id created");
             }
          }
         catch(ExceptionDemo2 ex)
         {
          System.out.println(ex.getMessage());
          System.out.println(ex);
         }
       }
  }
