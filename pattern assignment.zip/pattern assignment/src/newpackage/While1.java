package newpackage;
import java.util.Scanner;
class While
{
 public static void main(String args[])
 {
     Scanner sc =new Scanner(System.in);
     System.out.println("Enter any number:");
     int i=sc.nextInt();
     do
      {
       
       System.out.println(i);
       i++;
      }while(i<=10);
     System.out.println("exit");
 }
}
